package com.example.learnenglish.listener;

import com.example.learnenglish.model.Alphabet;

public interface OnQuestionCallbackAlphabet {
    void onClickQuestion(Alphabet alphabet);
}
