package com.example.learnenglish.listener;

import com.example.learnenglish.model.VocabularyItem;

public interface OnQuestionCallbackVocabularyItem {
    void onClickQuestion(VocabularyItem item);
}
